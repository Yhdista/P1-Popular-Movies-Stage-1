package com.yhdista.nanodegree.p1.interfaces;

import java.util.List;

/**
 * ControlFragment callbacks
 */
public interface DataCallbacks<E> {

    void setData(List<E> elements);

}
