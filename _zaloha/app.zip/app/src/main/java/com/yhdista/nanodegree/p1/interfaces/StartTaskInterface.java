package com.yhdista.nanodegree.p1.interfaces;

/**
 * Created by vlachjan on 14.8.2015.
 */
public interface StartTaskInterface<E> {

    void startTask(E e);
}

