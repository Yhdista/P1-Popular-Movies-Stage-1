package com.yhdista.nanodegree.p1.oodesign;

/**
 * Created by Yhdista on 18.8.2015.
 */
public class DataSingleton {

}
