package com.yhdista.nanodegree.p1.interfaces;

import android.view.View;

/**
 * Created by Yhdista on 18.8.2015.
 */
public interface OnItemClickListener {
    void onItemClick(View view, int position);
}
