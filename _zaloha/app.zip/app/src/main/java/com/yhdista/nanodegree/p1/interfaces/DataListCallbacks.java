package com.yhdista.nanodegree.p1.interfaces;

import java.util.List;

/**
 * ControlFragment callbacks
 */
public interface DataListCallbacks<E> {

    void setData(List<E> elements);

}
